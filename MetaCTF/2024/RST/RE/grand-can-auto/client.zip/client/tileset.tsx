<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tileset" tilewidth="64" tileheight="64" tilecount="130" columns="13">
 <image source="tileset.png" width="832" height="640"/>
</tileset>
