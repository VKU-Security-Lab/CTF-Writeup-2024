var searchData=
[
  ['enabled_0',['enabled',['../structhackrf__bool__user__settting.html#abce0d00cdfc5f8f7c805b6d31e08e53e',1,'hackrf_bool_user_settting']]],
  ['error_1',['error',['../structhackrf__m0__state.html#ada4b257582434b213889b8d9e3cc016e',1,'hackrf_m0_state']]]
];
