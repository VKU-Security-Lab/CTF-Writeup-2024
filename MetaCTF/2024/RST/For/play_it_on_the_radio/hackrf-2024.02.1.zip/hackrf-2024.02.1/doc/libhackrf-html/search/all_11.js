var searchData=
[
  ['valid_5flength_0',['valid_length',['../structhackrf__transfer.html#aa2345b6101874e5275e54f4905071fc9',1,'hackrf_transfer']]]
];
