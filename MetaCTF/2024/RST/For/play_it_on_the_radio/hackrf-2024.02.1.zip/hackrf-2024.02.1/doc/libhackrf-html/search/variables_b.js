var searchData=
[
  ['request_5fflag_0',['request_flag',['../structhackrf__m0__state.html#a472495580e79a9bebe89858e80c1663c',1,'hackrf_m0_state']]],
  ['requested_5fmode_1',['requested_mode',['../structhackrf__m0__state.html#a35b4a93a10d31c88075f1e98e26fbf25',1,'hackrf_m0_state']]],
  ['rx_2',['rx',['../structhackrf__bias__t__user__settting__req.html#a1dcf2291825eba104061bdbcdb51b53e',1,'hackrf_bias_t_user_settting_req']]],
  ['rx_5fctx_3',['rx_ctx',['../structhackrf__transfer.html#a3ee96e8bbf002ae8c13614f42a6c7945',1,'hackrf_transfer']]]
];
