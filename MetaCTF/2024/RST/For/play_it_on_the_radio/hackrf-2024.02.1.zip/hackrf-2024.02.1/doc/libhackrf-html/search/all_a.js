var searchData=
[
  ['next_5fmode_0',['next_mode',['../structhackrf__m0__state.html#aba8ece5555bdf8dca14314bab0141c17',1,'hackrf_m0_state']]],
  ['num_5fshortfalls_1',['num_shortfalls',['../structhackrf__m0__state.html#ad05a3ec701db15ee9e5db77a2b2b4f48',1,'hackrf_m0_state']]]
];
