var searchData=
[
  ['device_20listing_2c_20opening_2c_20closing_20and_20querying_0',['Device listing, opening, closing and querying',['../group__device.html',1,'']]]
];
