var searchData=
[
  ['usb_5fboard_5fids_0',['usb_board_ids',['../structhackrf__device__list.html#a78aca2090e643a9a31f12c61ffe838a8',1,'hackrf_device_list']]],
  ['usb_5fdevice_5findex_1',['usb_device_index',['../structhackrf__device__list.html#a74f9d54cab114558cbac198633017225',1,'hackrf_device_list']]],
  ['usb_5fdevicecount_2',['usb_devicecount',['../structhackrf__device__list.html#ade45abe8c0b741ca219555af31117406',1,'hackrf_device_list']]],
  ['usb_5fdevices_3',['usb_devices',['../structhackrf__device__list.html#abab1bfee7ce4361dd22900e1650da6a9',1,'hackrf_device_list']]]
];
