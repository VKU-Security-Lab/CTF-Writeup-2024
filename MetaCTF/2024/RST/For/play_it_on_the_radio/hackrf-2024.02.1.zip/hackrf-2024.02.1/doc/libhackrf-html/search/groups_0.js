var searchData=
[
  ['configuration_20of_20the_20rf_20hardware_0',['Configuration of the RF hardware',['../group__configuration.html',1,'']]]
];
