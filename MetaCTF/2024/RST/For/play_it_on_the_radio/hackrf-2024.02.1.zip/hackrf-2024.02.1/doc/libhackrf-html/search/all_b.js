var searchData=
[
  ['off_0',['off',['../structhackrf__bias__t__user__settting__req.html#ac9b5ed53ec082b8e511b99099ec30fe4',1,'hackrf_bias_t_user_settting_req']]],
  ['opera_20cake_20add_2don_20board_20functions_1',['Opera Cake add-on board functions',['../group__operacake.html',1,'']]],
  ['operacake_5fmode_5ffrequency_2',['OPERACAKE_MODE_FREQUENCY',['../group__operacake.html#ggab3a2bd2f3edbe0d7354bf8eee857bb40a4440eb06edc0d8823bc9b81c0a297c94',1,'hackrf.h']]],
  ['operacake_5fmode_5fmanual_3',['OPERACAKE_MODE_MANUAL',['../group__operacake.html#ggab3a2bd2f3edbe0d7354bf8eee857bb40aa9e7c912ff10c095ce4c8d03531e2666',1,'hackrf.h']]],
  ['operacake_5fmode_5ftime_4',['OPERACAKE_MODE_TIME',['../group__operacake.html#ggab3a2bd2f3edbe0d7354bf8eee857bb40aa15465e1ffe91c08a20f3b2752761c6c',1,'hackrf.h']]],
  ['operacake_5fpa1_5',['OPERACAKE_PA1',['../group__operacake.html#ggae6d9489172292d66a007dd395f3b125da18ca04ef8240b72590e9df37e6fc87c8',1,'hackrf.h']]],
  ['operacake_5fpa2_6',['OPERACAKE_PA2',['../group__operacake.html#ggae6d9489172292d66a007dd395f3b125da4052e634b0eb9e7c4a5094704e42620a',1,'hackrf.h']]],
  ['operacake_5fpa3_7',['OPERACAKE_PA3',['../group__operacake.html#ggae6d9489172292d66a007dd395f3b125dab1b1db5542736f2a64bd1e23bebdb96c',1,'hackrf.h']]],
  ['operacake_5fpa4_8',['OPERACAKE_PA4',['../group__operacake.html#ggae6d9489172292d66a007dd395f3b125da7c1dbc97e30335bdce78b89dcc028689',1,'hackrf.h']]],
  ['operacake_5fpb1_9',['OPERACAKE_PB1',['../group__operacake.html#ggae6d9489172292d66a007dd395f3b125da5c901f10dbc0ff0588f2a1ad8a65a3f5',1,'hackrf.h']]],
  ['operacake_5fpb2_10',['OPERACAKE_PB2',['../group__operacake.html#ggae6d9489172292d66a007dd395f3b125da169a8a2ee1b563b9c1b2beab3a6efd57',1,'hackrf.h']]],
  ['operacake_5fpb3_11',['OPERACAKE_PB3',['../group__operacake.html#ggae6d9489172292d66a007dd395f3b125da8b5bb435ffc9cce3f8d4154e1add86b1',1,'hackrf.h']]],
  ['operacake_5fpb4_12',['OPERACAKE_PB4',['../group__operacake.html#ggae6d9489172292d66a007dd395f3b125da1278829a082cc135d8f2dd96716766f6',1,'hackrf.h']]],
  ['operacake_5fports_13',['operacake_ports',['../group__operacake.html#gae6d9489172292d66a007dd395f3b125d',1,'hackrf.h']]],
  ['operacake_5fswitching_5fmode_14',['operacake_switching_mode',['../group__operacake.html#gab3a2bd2f3edbe0d7354bf8eee857bb40',1,'hackrf.h']]]
];
