var searchData=
[
  ['samples_5fper_5fblock_0',['SAMPLES_PER_BLOCK',['../group__streaming.html#gae581302423a0d3dd5a2e68139426ba06',1,'hackrf.h']]],
  ['serial_5fno_1',['serial_no',['../structread__partid__serialno__t.html#a634d671b814d50ce791e294bd13a42e3',1,'read_partid_serialno_t']]],
  ['serial_5fnumbers_2',['serial_numbers',['../structhackrf__device__list.html#a135930ddf108db78741b61fcde8293f0',1,'hackrf_device_list']]],
  ['shortfall_5flimit_3',['shortfall_limit',['../structhackrf__m0__state.html#aee0fe3fe66789bbf3aa42b212b156737',1,'hackrf_m0_state']]],
  ['sweep_5fstyle_4',['sweep_style',['../group__streaming.html#gadd13ea4602d90423052eb55dafab007a',1,'hackrf.h']]]
];
