var searchData=
[
  ['longest_5fshortfall_0',['longest_shortfall',['../structhackrf__m0__state.html#a0304e3f4411c3d08a52104c4caa5487d',1,'hackrf_m0_state']]]
];
