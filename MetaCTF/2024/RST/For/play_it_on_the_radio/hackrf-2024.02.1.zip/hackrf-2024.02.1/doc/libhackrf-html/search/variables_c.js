var searchData=
[
  ['serial_5fno_0',['serial_no',['../structread__partid__serialno__t.html#a634d671b814d50ce791e294bd13a42e3',1,'read_partid_serialno_t']]],
  ['serial_5fnumbers_1',['serial_numbers',['../structhackrf__device__list.html#a135930ddf108db78741b61fcde8293f0',1,'hackrf_device_list']]],
  ['shortfall_5flimit_2',['shortfall_limit',['../structhackrf__m0__state.html#aee0fe3fe66789bbf3aa42b212b156737',1,'hackrf_m0_state']]]
];
