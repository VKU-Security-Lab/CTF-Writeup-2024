var searchData=
[
  ['transmit_20_26_20receive_20operation_0',['Transmit &amp; receive operation',['../group__streaming.html',1,'']]]
];
