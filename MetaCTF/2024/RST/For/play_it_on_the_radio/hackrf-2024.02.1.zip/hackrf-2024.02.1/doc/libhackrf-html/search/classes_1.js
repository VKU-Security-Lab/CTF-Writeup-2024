var searchData=
[
  ['read_5fpartid_5fserialno_5ft_0',['read_partid_serialno_t',['../structread__partid__serialno__t.html',1,'']]]
];
