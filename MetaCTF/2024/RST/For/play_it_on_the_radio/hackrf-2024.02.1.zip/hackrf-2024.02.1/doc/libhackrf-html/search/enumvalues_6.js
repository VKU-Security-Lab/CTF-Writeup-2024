var searchData=
[
  ['usb_5fboard_5fid_5fhackrf_5fone_0',['USB_BOARD_ID_HACKRF_ONE',['../group__device.html#gga5bb6d21d5bc124638ab0a9d87d136658af9806d38e397eab20d771416578e5008',1,'hackrf.h']]],
  ['usb_5fboard_5fid_5finvalid_1',['USB_BOARD_ID_INVALID',['../group__device.html#gga5bb6d21d5bc124638ab0a9d87d136658a2ff16eb544fbbbfd1b4c2459eef2bd62',1,'hackrf.h']]],
  ['usb_5fboard_5fid_5fjawbreaker_2',['USB_BOARD_ID_JAWBREAKER',['../group__device.html#gga5bb6d21d5bc124638ab0a9d87d136658acf755d9214597d7c107d6910414f911c',1,'hackrf.h']]],
  ['usb_5fboard_5fid_5frad1o_3',['USB_BOARD_ID_RAD1O',['../group__device.html#gga5bb6d21d5bc124638ab0a9d87d136658acf3098faf7a9ba28029101065eecf906',1,'hackrf.h']]]
];
