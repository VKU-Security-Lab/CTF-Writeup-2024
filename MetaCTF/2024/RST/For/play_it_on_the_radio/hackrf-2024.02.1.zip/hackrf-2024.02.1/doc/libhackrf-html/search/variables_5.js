var searchData=
[
  ['freq_5fmax_0',['freq_max',['../structhackrf__operacake__freq__range.html#abea405ea49665b639447c05d1b0ef416',1,'hackrf_operacake_freq_range']]],
  ['freq_5fmin_1',['freq_min',['../structhackrf__operacake__freq__range.html#a68f3e93be3ace770139fa674b6cfab60',1,'hackrf_operacake_freq_range']]]
];
