var searchData=
[
  ['part_5fid_0',['part_id',['../structread__partid__serialno__t.html#ad4cafe52c12699f8907424bfcf8504e8',1,'read_partid_serialno_t']]],
  ['port_1',['port',['../structhackrf__operacake__dwell__time.html#a7eac47c3478688e2a964d981c24586ba',1,'hackrf_operacake_dwell_time::port()'],['../structhackrf__operacake__freq__range.html#a1b9e48a2c23767f55f8c549a296cece7',1,'hackrf_operacake_freq_range::port()']]]
];
