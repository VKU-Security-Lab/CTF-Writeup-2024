var searchData=
[
  ['operacake_5fports_0',['operacake_ports',['../group__operacake.html#gae6d9489172292d66a007dd395f3b125d',1,'hackrf.h']]],
  ['operacake_5fswitching_5fmode_1',['operacake_switching_mode',['../group__operacake.html#gab3a2bd2f3edbe0d7354bf8eee857bb40',1,'hackrf.h']]]
];
