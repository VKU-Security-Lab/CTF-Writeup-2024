var searchData=
[
  ['device_0',['device',['../structhackrf__transfer.html#a5e3acfe633123eaf8ab5874b6c0aa44d',1,'hackrf_transfer']]],
  ['device_20listing_2c_20opening_2c_20closing_20and_20querying_1',['Device listing, opening, closing and querying',['../group__device.html',1,'']]],
  ['devicecount_2',['devicecount',['../structhackrf__device__list.html#a29054d1d2ec8042561cf21e1ef46b259',1,'hackrf_device_list']]],
  ['do_5fupdate_3',['do_update',['../structhackrf__bool__user__settting.html#ac702c93381b2a006017374f8395864a3',1,'hackrf_bool_user_settting']]],
  ['dwell_4',['dwell',['../structhackrf__operacake__dwell__time.html#ad5ad8a9b6e08b3d92b1725b9b149f852',1,'hackrf_operacake_dwell_time']]]
];
