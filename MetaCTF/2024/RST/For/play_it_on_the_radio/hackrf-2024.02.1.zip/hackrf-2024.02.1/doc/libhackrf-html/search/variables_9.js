var searchData=
[
  ['off_0',['off',['../structhackrf__bias__t__user__settting__req.html#ac9b5ed53ec082b8e511b99099ec30fe4',1,'hackrf_bias_t_user_settting_req']]]
];
