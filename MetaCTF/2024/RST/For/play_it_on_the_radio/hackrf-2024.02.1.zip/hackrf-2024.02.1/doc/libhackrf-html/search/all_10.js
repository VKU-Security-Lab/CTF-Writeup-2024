var searchData=
[
  ['usb_5fboard_5fid_5fhackrf_5fone_0',['USB_BOARD_ID_HACKRF_ONE',['../group__device.html#gga5bb6d21d5bc124638ab0a9d87d136658af9806d38e397eab20d771416578e5008',1,'hackrf.h']]],
  ['usb_5fboard_5fid_5finvalid_1',['USB_BOARD_ID_INVALID',['../group__device.html#gga5bb6d21d5bc124638ab0a9d87d136658a2ff16eb544fbbbfd1b4c2459eef2bd62',1,'hackrf.h']]],
  ['usb_5fboard_5fid_5fjawbreaker_2',['USB_BOARD_ID_JAWBREAKER',['../group__device.html#gga5bb6d21d5bc124638ab0a9d87d136658acf755d9214597d7c107d6910414f911c',1,'hackrf.h']]],
  ['usb_5fboard_5fid_5frad1o_3',['USB_BOARD_ID_RAD1O',['../group__device.html#gga5bb6d21d5bc124638ab0a9d87d136658acf3098faf7a9ba28029101065eecf906',1,'hackrf.h']]],
  ['usb_5fboard_5fids_4',['usb_board_ids',['../structhackrf__device__list.html#a78aca2090e643a9a31f12c61ffe838a8',1,'hackrf_device_list']]],
  ['usb_5fdevice_5findex_5',['usb_device_index',['../structhackrf__device__list.html#a74f9d54cab114558cbac198633017225',1,'hackrf_device_list']]],
  ['usb_5fdevicecount_6',['usb_devicecount',['../structhackrf__device__list.html#ade45abe8c0b741ca219555af31117406',1,'hackrf_device_list']]],
  ['usb_5fdevices_7',['usb_devices',['../structhackrf__device__list.html#abab1bfee7ce4361dd22900e1650da6a9',1,'hackrf_device_list']]]
];
