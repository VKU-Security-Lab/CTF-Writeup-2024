var searchData=
[
  ['buffer_0',['buffer',['../structhackrf__transfer.html#a88d1d91a12f0226250a4784101717ba3',1,'hackrf_transfer']]],
  ['buffer_5flength_1',['buffer_length',['../structhackrf__transfer.html#a1b98fe1301eacde6c7184f4949610795',1,'hackrf_transfer']]]
];
