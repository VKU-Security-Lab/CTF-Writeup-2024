var searchData=
[
  ['library_20related_20functions_20and_20enums_0',['Library related functions and enums',['../group__library.html',1,'']]],
  ['linear_1',['LINEAR',['../group__streaming.html#ggadd13ea4602d90423052eb55dafab007aadc101ebf31c49c2d4b80b7c6f59f22cb',1,'hackrf.h']]],
  ['longest_5fshortfall_2',['longest_shortfall',['../structhackrf__m0__state.html#a0304e3f4411c3d08a52104c4caa5487d',1,'hackrf_m0_state']]]
];
