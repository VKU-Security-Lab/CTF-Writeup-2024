var searchData=
[
  ['linear_0',['LINEAR',['../group__streaming.html#ggadd13ea4602d90423052eb55dafab007aadc101ebf31c49c2d4b80b7c6f59f22cb',1,'hackrf.h']]]
];
