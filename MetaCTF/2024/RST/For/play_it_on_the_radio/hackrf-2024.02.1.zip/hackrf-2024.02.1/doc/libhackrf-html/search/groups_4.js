var searchData=
[
  ['opera_20cake_20add_2don_20board_20functions_0',['Opera Cake add-on board functions',['../group__operacake.html',1,'']]]
];
