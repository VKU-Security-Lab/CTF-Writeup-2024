#ifndef __RAD1O_UBUNTU18_H__
#define __RAD1O_UBUNTU18_H__
#include "fonts.h"

extern const struct FONT_DEF Font_Ubuntu18pt;

#endif
