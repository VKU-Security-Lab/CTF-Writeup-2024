#ifndef __RAD1O_DECODER_H__
#define __RAD1O_DECODER_H__

#include <stdint.h>

uint8_t* rad1o_pk_decode(const uint8_t* data, int* len);

#endif
